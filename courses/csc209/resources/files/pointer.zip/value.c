#include <stdio.h>

int calc(char *a){
	//printf("calc %d\n", sizeof(a));
	//printf("inside calc %u %ull\n", &a[0], &a);
//	a[3] *= 2;	
    //*(a) == a[0]	
    a[3] += 1;
}

int main(){
	int a = 100;
	int b = 200;
	int c = 50;
	int d = 300;

	char *x = &a;
	x[3] += 1;

	//calc(&a);
	printf("%d %d %d %d\n", a, b, c, d); 
}
