#include <stdio.h>

void alloc(int **a, int n){
//	int b[10000000] = {1, 2, 3, 4, 5};
	int *b = malloc(sizeof(int) * n);
	b[0] = 1, b[1] = 2, b[2] = 3, b[3] = 4;
	*a = b;
}

int main(){
	int *a; // int a[10];
	printf("current value of a: %u\n", a);

	alloc(&a, 1000000000);
	printf("current value of a: %u\n", a);
	for (int i=0; i<5; i++)
		printf("%d ", a[i]);
	printf("\n");

}
