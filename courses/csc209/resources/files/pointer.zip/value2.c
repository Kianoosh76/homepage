#include <stdio.h>

int g = 100; 

int f(int *a){
	a = &g;
	(*a)++;
}

int main(){
	int a = 10;
    f(&a);	
	printf("%d\n", a);
}


