#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

int **alloc(int n, int m){
	int **a = malloc(sizeof(int *) * n);
	
	for (int i=0; i<n; i++){
		a[i] = malloc(sizeof(int) * m);
	}
	
	return a;
}

void free(int **a, int n, int m){
	for (int i=0; i<n; i++){
		free(a[i]);
	}

	free(a);
}

int main(){
	int **arr = alloc(3, 4);
	arr[2][1] = 2;
	
	printf("%d\n", arr[2][1]);
//	return;
	while(true){
//		int a[100000];
		int *a = malloc(100000 * sizeof(int));
		printf("%d\n", a);
		free(a);
		sleep(0.01);
	}
}
