#include <stdio.h>

void swap(int *a, int *b){
	*a ^= *b ^= *a ^= *b;
}

int main(){
	int a = 'a';

	char *b = &a;
	for (int i=0; i<4; i++){
		printf("%d ", b[i]);
	}
	printf("\n");

	char c = 0;

	int *d = &c;
	*d = a;

	printf("%d\n", c);

	float f = 23.45;
	int *g = &f;
	*g = 9.19;
	printf("%f\n", f);


}
