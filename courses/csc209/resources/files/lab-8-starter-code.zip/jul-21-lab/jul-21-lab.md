

<title>
    CSC 209H: Pipes, Exec, and Dup2
</title>
  </head>
  <body>

<div class="title">
  <h1>
    CSC 209H: Week 9 Lab (Pipes, Exec, and Dup2)
  </h1>
</div>

<!--#include virtual="/~209/navigation.txt" -->

<div class="content">


<h2>Introduction</h2>

<p>
    In any application that requires a user to login, the user id and password
    must be validated. One approach to validation is to hand the task off to a
    separate process. The data is transferred to the new process over <tt>stdin</tt>,
    because if they were given as command-line arguments they would be visible to
    programs such as <tt>ps</tt> that inspect the state of the system.
</p>

<p>
    For this lab, you have been given a program that validates user id and passwords
    named <tt>validate</tt>. Your
    task is to apply what you've learned about processes and pipes to create a
    program that runs this validation program in a child process and reports the
    result of the validation.
</p>

<h2>Step 1: Study <tt>validate.c</tt></h2>

<p>
    Spend some time reading, compiling, and playing with the <tt>validate</tt>
    program. Here are some questions that you'll need to answer as you explore the code:
</p>

<ul>
    <li>How does <tt>validate</tt> get input?
    <li>How many bytes does <tt>validate</tt> expect to receive on each call to
        <tt>read</tt>?
    <li>Does <tt>validate</tt> expect end of line characters? Null terminated strings?
    <li>How does <tt>validate</tt> report whether the username and password it has
        received are valid?
</ul>

<p>
    Note: You may not modify <tt>validate.c</tt> to complete your task for this lab.
    We will only be testing the program you write; we will supply our own, original
    version of <tt>validate.c</tt>.
</p>

<h2>Step 2: Create <tt>checkpasswd.c</tt></h2>

<p>
    Your task is to complete <tt>checkpasswd.c</tt>, which reads a user id and
    password from <tt>stdin</tt>, creates a new process to run the <tt>validate</tt>
    program, sends it the user id and password, and prints a message to <tt>stdout</tt>
    reporting whether the given user id-password pair is valid.
</p>

<p>
    Your program should print one of three messages (which are defined in your starter
    code as constants):
</p>

<ul>
    <li>"Password verified\n" if the user id and password match.
    <li>"Invalid password\n" if the user id exists but the password does not match.
    <li>"No such user\n" if the user id is not recognized.
</ul>

<p>
    Note that the given password file contains a few entries that are invalid. Those
    examples are expected to fail, but you may find them useful for testing.
</p>

<p>
    You may <b>not</b> use <tt>popen</tt> in your solution. The goal is to practice
    with <tt>fork</tt> and <tt>wait</tt>, <tt>pipe</tt>, and <tt>dup2</tt>.
</p>



</div>
<!--#include virtual="/~209/pageend.txt" -->
