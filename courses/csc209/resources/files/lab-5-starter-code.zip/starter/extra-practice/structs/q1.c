/* 
Write the code for the add_all function below.
The function returns the sum of all numbers in the pointed-to list.
A sample call is provided in main().
*/

#include <stdio.h>
#include <stdlib.h>

struct node {
    int *num;
    struct node *next;
};

int add_all(struct node **ptr) {
    // todo
}

int main() {
    int x = 10, y = 20, z = 30;
    struct node n1, n2, n3;
    struct node *ptr = &n1;
    n1.num = &x;
    n1.next = &n2;
    n2.num = &y;
    n2.next = &n3;
    n3.num = &z;
    n3.next = NULL;

    printf("%d\n", add_all(&ptr)); // Should print 60

    return 0;

}
