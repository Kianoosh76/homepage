#include <stdio.h>
#include <stdlib.h>


struct ll_node {
    int value;
    struct ll_node *next;
};

// TODO: return the sum of all the values inside the linked list.
int sum_ll(struct ll_node *head){
    // TODO
}

// TODO: insert a new ll_node with a value of <value> at index <index> in the linked list 
int insert_at_index(struct ll_node *head, int value, int index){
    // TODO
}

// TODO: delete the ll_node at index <index> in the linked list 
int delete_at_index(struct ll_node *head, int index){
    // TODO
}


// This overly complex code reads integers from stdin and places them in 
// a linked list. Then, it sums the items in the list and prints the result.
int main() {
    int user_inp;
    int sum;

    // Using a dummy head node
    struct ll_node *front = malloc(sizeof(struct ll_node));
    struct ll_node *current = front;

    while (scanf("%d", &user_inp) != EOF) {
        current->next = malloc(sizeof(struct ll_node));
        current = current->next;

        current->value = user_inp;
        current->next = NULL;
    }


    return 0;
}
