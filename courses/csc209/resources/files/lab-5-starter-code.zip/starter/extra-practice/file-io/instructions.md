# File I/O

## Introduction


Copying many small files with SCP to the lab is inefficent and relatively slow. Copying large files on the other hand takes advantage of techniques and algorithms used in computer networking to speed up the data transfer of large files.

In this lab you are given a custom file type representing the CSC209 archive. This archive concatenates files (creating one large file out of many small files), your task is to write a program that can traverse the archive file and extract the files within it. Thus producing the original files again.

This week's lab has starter code. See encrypt.c. 


## Task

The file structure of the archive file is specified in encode.c You will use hexhump to inspect the file and then write code to unarchive all the files contained in the sample archive provided.

Each archive follows the same structure
- A header containing "csc209.Archive"
- One integer specifying the number of files
- One long for each file specifying the file size
- One string, max strlen is 64, specifying the archived file name
- The file contents in the order in which the files are listed.

**Complete the unarchive function.**



