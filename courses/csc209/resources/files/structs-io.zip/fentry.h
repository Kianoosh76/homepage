struct fentry{
	char name[8];
	int block;
	int size;
};
