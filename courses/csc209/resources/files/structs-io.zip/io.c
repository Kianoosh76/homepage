#include <stdio.h>

int main(){
	FILE *p = stdout;
//	p = fopen("a.txt", "w");
	fprintf(p, "%llu\n", p);

	fprintf(p, "%llu\n", stdout);

	fclose(p);
}
