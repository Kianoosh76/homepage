#include <stdio.h>
#include <stdlib.h>
#include "fentry.h"

int main(){
	struct fentry *fentry = malloc(sizeof(struct fentry));

	FILE *file = fopen("filesystem", "r");
	
	fread(fentry, sizeof(struct fentry), 1, file);

	printf("%s %d %d", fentry->name, fentry->block, fentry->size);

}
