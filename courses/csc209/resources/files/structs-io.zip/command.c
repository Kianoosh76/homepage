#include <stdio.h>

int main(int argc, char **argv){
	printf("total number of args: %d\n", argc);
	for (int i=0; i<argc; i++)
		printf("arg %i: %s\n", i, argv[i]);
}
