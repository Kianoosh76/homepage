#include <stdio.h>

typedef long long ll;

struct cycle;

struct cycle {
	int count;
	struct cycle *next;
};

struct info {
	int age;
	int height;
};

typedef struct {
 	int id;
  	struct info info;
  	char name[8]; 
} student;

/*struct student {
	int id;
	struct info info;
	char name[8];
};*/

const char *c = "name";

void initialize(student *st){
	st->id = 0; // (*st).id
	st->info.age = 0;
	st->info.height = 150;
	strcpy(st->name, "--");
}


int main(){
	printf("%lu\n", sizeof(struct cycle));	
	
	student st; // = {.age = 2, .name = "name", .id = 1};

	initialize(&st);
	printf("student age is %d, name %s\n", st.info.age, st.name);

//	student.name = c;
//	student.name = malloc(10);
	strncpy(st.name, c, 10);

	printf("%llu %llu", st.name, c); 

///	printf("%lu\n", &student);
//	printf("%lu\n", &(student.id));
//	printf("%lu\n", &(student.age));
//	printf("%lu\n", student.name);
//	printf("%s\n", student.name);
}
