#include <stdio.h>
#include "fentry.h"

int main(){
	struct fentry fentry = {.name = "a.txt", .block = 2, .size = 129};
	
	FILE *file = fopen("filesystem", "w");
	fwrite(&fentry, sizeof(fentry), 1, file);

	fclose(file);
}
