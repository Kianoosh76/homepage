#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdbool.h>
#include <sys/select.h>
#include <unistd.h>
#include <unistd.h>
int main(){
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == -1){
		perror("socket");
		return 1;
	}

	struct sockaddr_in server = {.sin_family = AF_INET, .sin_port = htons(8000), .sin_addr = {inet_addr("127.0.0.1")}}, cli;

	if (connect(sock, &server, sizeof(server))){
		perror("connect");
		return 1;
	}

	printf("connected\n");
	while(true){
		char buf[100];
		scanf("%s", buf);
		write(sock, buf, 100);

	}

}
