#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main(){
	int fd[2];

	if (pipe(fd) == -1){
		perror("pipe");
		exit(1);
	}

	char filename[101];
	while(true){
		scanf("%s", filename);
		
		if (fork() == 0){ // child
			dup2(fd[1], STDOUT_FILENO);
			execl("/usr/bin/wc", "/usr/bin/wc", "-l", filename, NULL);
		} 
		else {
			wait();
			char buf[101] = {};
			if (read(fd[0], buf, 100) == -1){
				perror("read");
				exit(1);	
			};
			
			char *space = strchr(buf, ' ');
			if (space != NULL){
				*space = 0;
			}

			printf("%s lines\n", buf);
		}

	}
}
