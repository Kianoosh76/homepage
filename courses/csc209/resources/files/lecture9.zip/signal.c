#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>

int child_pid;

void signal_handler(int sig){
	printf("signal %d received\n", sig);
	kill(child_pid, SIGSEGV);
}

int main(){
	signal(SIGINT, signal_handler);

	while(true){
		if ((child_pid = fork()) == 0){
			execl("stall", "stall", NULL);
		}	
		else{
			int st;
			wait(&st);
			printf("child exited with code %d\n", st);
		}	
	}
}
