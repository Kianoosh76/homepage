#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>

void ignore(int sig){

}

int main(){
	signal(SIGINT, ignore);
	while(1);
}
