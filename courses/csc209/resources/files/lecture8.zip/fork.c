#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>

int main(){
	printf("before forking %d -- %d\n", getpid(), getppid());
	int pid = fork();

	if (pid == 0){ // I'm the child process
		printf("after forking %d -- %d\n", getpid(), getppid());
		execl("/bin/ls", "/bin/ls", NULL);
	}
	else { // I'm the parent and pid is my child's pid
		printf("after forking %d -- %d\n", getpid(), getppid());
		int code;
	   	wait(&code);
		printf("child exited with status code %d\n", code);
	}

}

