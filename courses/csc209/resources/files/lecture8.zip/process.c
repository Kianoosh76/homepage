#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>

int main(){
	printf("before exec\n");
	execl("/bin/ls", "/bin/ls", NULL);
	printf("after exec\n");
//	execl("process2", "process2", "1", "hello", "4.53", NULL);	
}
