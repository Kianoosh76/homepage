#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>

int main(){
	char buf[4] = {};

	int fd = open("a.txt", 0);
	
	if (fd == -1){
		perror("error");
		return 1;
	}

	if (fork() == 0){
		int out = read(fd, buf, 3);
		printf("%d %s\n", fd, buf);
		
		int fd = open("weird-out.txt", O_WRONLY | O_CREAT, 0777);
		dup2(fd, STDOUT_FILENO); 
		execl("weird", "weird", NULL);
	}
	else{
		wait(NULL);
		
		int out = read(fd, buf, 3);
		printf("%d %s\n", fd, buf);
	}
}
