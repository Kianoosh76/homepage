#include <unistd.h>
#include <stdio.h>

int main(){
	char buf[4];
	read(3, buf, 3);
	printf("%s\n", buf);
}
