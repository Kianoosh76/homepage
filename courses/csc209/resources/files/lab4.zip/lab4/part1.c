#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void letterSwap(char*, char*, int*, int);
void exclamations(char*);

int main() {

        // You can write some code to test your functions here.
}

/*TODO: Fill in the below function, letterSwap, which takes two input strings, one array, and the size of that array,
 * and swaps the letters at the indices given in the array.
 *
 * For example, if replArray[0] = 3, then letterSwap() must swap the letters at index 3 between the two strings. It
 * will loop through the array and continue swapping until it reaches the end of the array.
 *
 * So if our two strings were 'Hello' and 'Goodbye', and replArray = [1, 3] then letterSwap would result in the strings
 * 'Holdo' and 'Geolbye'.
 *
 * Modify the original strings, don't make copies.
 *
 * Make sure you are handling your strings appropriately and not accidentally removing the '\0' byte or otherwise
 * reading or writing from memory that you shouldn't be. */

void letterSwap(char *str1, char *str2, int *replArray, int size) {

}

/*TODO: Fill in the below function, exclamations, which takes a single input string and updates it so that each word is
 * followed by a '!'.
 *
 * For example, the string 'I am yelling now' becomes 'I! am! yelling! now!'
 *
 * Do NOT make a copy of the string. You must modify the original string.
 *
 * Make sure you handle the following edge cases:
 *      - Special characters in strings
 *      - String that starts with a space
 *      - Multiple spaces in between words
 *      - Make sure the input string actually has enough space in the array to add exclamation points. If it doesn't,
 *      don't add them. Do NOT write any out-of-bounds memory. */

void exclamations(char *str) {

}
