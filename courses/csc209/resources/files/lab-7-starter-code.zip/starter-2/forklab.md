

# CSC 209H: Week 8 Lab (fork)


<h2>Introduction</h2>

<p>The purpose of this exercise is to play with <tt>fork</tt>, and get a feeling for
how it works.  It should be a fairly short lab. 
</p>


<h2>Task 1: Run the <code>simplefork</code> program</h2>

<p>Open <code>simplefork.c</code> in your favourite editor and then read it to see
what it is doing. Use the <tt>Makefile</tt> to compile and run it a few times.
As you read the output, recall from the videos (which you may not have watched yet)
that it is up to the operating system to decide whether the parent or the child
runs first after the fork call, and it <b>may</b> change from run to run (!!!).</p>

<p> Discuss the following questions with your TAs to arrive at the answers. (10 minutes)</p>
<p><b>Question 1</b>: Which lines of output are printed more than once?</p>

<p><b>Question 2</b>: Enumerate some of the different possible orders for the output. For example,
"ABDEBCE" is a legal ordering. Note that you may not be able to reproduce all input orders,
since they are based on timing you do not control. To make it easy for us to mark this,
please also include the line "Total orderings = N", where N is the number of orderings
you discovered.</p>

<h2>Task 2: Fork in a loop</h2>

<p>The program in <code>forkloop.c</code> takes one command-line argument that is
the number of iterations of the loop that calls fork. Try it with at least 2, 3 and
4 as command-line arguments.</p>

<p> Discuss the following questions with your TAs to arrive at the answers. (5 minutes)</p>

<p><b>Question 3</b>: How many processes are created (including the original parent) when
<code>forkloop</code> is called with 4 as an argument?</p>

<p><b>Question 4</b>: Use an ASCII diagram (or whiteboard) to show the processes and their
relationships when you run it with the command-line argument "3". For example, the diagram for
<code>forkloop</code> with command-line argument "2" (assuming the process id of the parent is 414
and the process ids of the children are 416, 417, and 420) might be:</p>

<pre>    414 -> 416 -> 420
    414 -> 417
</pre>

<p>Notice that the shell prompt sometimes appears in the middle of the output.
That happens because the parent process exits before some of the children get a
chance to print their output.</p>

<p>You may also see a change in the value of the parent pid. We are getting the parent's pid
from the <code>getppid</code> system call. If a process's parent has
terminated, the process gets "adopted" by the init process which has a
process id of 1. So when you see the ppid of a process is 1, that means that its
parent has terminated.</p>

<h2>Task 3: Make the parent create all the new processes</h2>

<p>  Modify the <code>parentcreates.c</code> program so that child processes do
not create additional children. Only the original parent process should create children.
Both the parent and the child will print the output line. The resulting diagram
will look something like the following when <code>parentcreates 3</code> is
called. Note that the process ids will differ and that the child process ids will
not necessarily be in sequence.</p>

<pre>    414 -> 416
    414 -> 417
    414 -> 420
</pre>

<h2>Task 4: Limit the processes each process may spawn</h2>

<p>Modify the <code>childcreates.c</code> program so that each process creates at most
one new process. All
processes will print the output line. The resulting diagram will look something
like the following when <code>childcreates 3</code> is called:</p>

<pre>    414 -> 416 -> 417 -> 420
</pre>

<h2>Task 5: Add <tt>wait</tt> to delay the exit of the parent</h2>

<p> Earlier, you may have seen that a parent process can terminate before its children. (If you didn't see that phenomenon, try running the <tt>forkloop</tt> program with a larger command-line argument like 5 or 6.)
</p>

<p>However, a process <i>can</i> wait for its children to terminate. (Normally, when you run a program from the shell, have you noticed that the prompt doesn't appear until the program terminates?) If a process wants to wait
until all its children have terminated, it needs to call <tt>wait</tt> once for each
child. Add the appropriate <code>wait</code> calls to both <code>childcreates</code> and <code>parentcreates</code> to ensure that each
parent does not terminate before its children.</p>

<p>Your programs should call <code>wait</code> as late as possible. If the process has other work to do, like creating more children, it
should create the children before calling <code>wait</code>. If you call <tt>wait</tt> too early, then you end up slowing down your program because you are "serializing it" (reducing the number of things that run simultaneously, in parallel).</p>




</div>
<!--#include virtual="/~209/pageend.txt" -->
