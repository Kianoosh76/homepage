#include <string.h>
#include <stdio.h>

int countEven(int*, int);
void copy_double(int*, int);
void reverse_array();
void random_array();

// Scroll down to see the tasks for this lab.

//Some code to test your solutions
int main() {

	// Should print 2
	int arr[5] = {1, 2, 3, 4, 5};
	printf ("%d\n", countEven(arr, 5));

	// Should print 7
	int arr2[10] = {2, 3, 4, 5 ,4 ,5, 78, 10, 50314, 0};
	printf ("%d\n", countEven(arr2, 10));

	// Should print 2, 10, 6, 4, 30
	int arr3[5] = {1, 5, 3, 2, 15};
	copy_double(arr3, 5);

	// Should print 15, 2, 3, 5, 1
	reverse_array(arr3, 5);

	// This will be different output each time, but you should be able to figure out
	// if it's working as long as you have your print statements set up
	random_array();

	return 0;
}

// TODO: Fill in the function below, countEven, which takes an array of integers and its length,
// and returns the number of even integers contained in the list. ONLY use the pointer notation for
// this, not the square brackets notation.
int countEven(int* array, int length) {

	// YOUR CODE GOES HERE
}

// TODO: Fill in the function copy_double so that it doubles each integer in the given array and puts the
// doubled int into a second array. Print the second array. You can use square bracket or pointer notation for this.
void copy_double(int* array, int length) {

	// YOUR CODE GOES HERE
}

// TODO: Fill in the function reverse_array, which given an array and its size, prints that array in reverse.
// You don't have to copy it into a new array. ONLY use pointer notation for this.
void reverse_array(int* array, int length) {
	
	// YOUR CODE GOES HERE
}

// TODO: Fill in the function random_array() so that it first generates an array of size 5 whose elements
// are randomized integers and prints out the array. Then, have it calculate the sum of the elements in 
// the array and print that out. Then, have it count the number of integers in the array that are less than 10.

void random_array() {
	// Generate the array and fill it with random ints
	
	// Print it out
	
	// Count and print out the number of ints that are less than 10
}

