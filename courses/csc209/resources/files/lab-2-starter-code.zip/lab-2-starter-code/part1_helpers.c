#include <stdlib.h>


// ❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️
// STUDENTS, PLEASE DO NOT LOOK AT THIS CODE!!!!! (only after tutorial :) )
// ❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️❗️
































































int ******createScaryPointer(){
    int num = 7;
    int *p1 = malloc(sizeof(int));
    *p1 = num;
    int **p2 = malloc(sizeof(int*));
    *p2 = p1;
    int ***p3 = malloc(sizeof(int**));
    *p3 = p2;
    int ****p4 = malloc(sizeof(int***));
    *p4 = p3;
    int *****p5 = malloc(sizeof(int****));
    *p5 = p4;
    int ******p6 = malloc(sizeof(int*****));
    *p6 = p5;

    return p6;

}




