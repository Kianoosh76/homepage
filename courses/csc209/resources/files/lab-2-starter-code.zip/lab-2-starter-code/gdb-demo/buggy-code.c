#include <stdio.h>

// gcc -g buggy-code.c
int calculateLength(int *arr, int arrLength)
{
    int sum = 1;
    int i = 0;

    while (i < arrLength)
    {
        sum += arr[i];
        i += i;
    }

    return sum;
}

int main()
{
    int arr[] = {1, 2, 3, 4};
    printf("Sum of arr=%d.\n", calculateLength(arr, 4));
}