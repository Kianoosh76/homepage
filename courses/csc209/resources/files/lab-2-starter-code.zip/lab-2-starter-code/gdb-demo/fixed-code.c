#include <stdio.h>

int calculateLength(int *arr, int arrLength)
{
    int sum = 0;
    int i = 0;

    while (i < arrLength)
    {
        sum += arr[i];
        i++;
    }

    return sum;
}

int main()
{
    int arr[] = {1, 2, 3, 4};
    printf("Sum of arr=%d.\n", calculateLength(arr, 4));
}