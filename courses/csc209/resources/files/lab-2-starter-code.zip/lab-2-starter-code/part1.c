#include <stdio.h>
#include <stdlib.h>
#include "part1_helpers.h"


// ❗️INSTRUCTIONS❗️:
// You can can compile this code by running "make". 
// (make sure you are in the same directory as the Makefile)
// then execute ./part1
// ❗️Note:❗️ you *WILL* see some errors when you initially compile this code. 
// I HIGHLY recommend answering all the questions first before you compile and run this code.
// (the compiler will spoil some of the questions for you 😩). You can then comment out the 
// lines that produce errors so that you can run your code.

// Good luck! 



int *giveMeAPointer(){
    int num = 45;
    return &num;
}



int main(){
    int numbers[] = {1,2,3,4};

    // QUESTION: what is this pointer referring to?
    int *mystery = numbers;

    // QUESTION: what is this pointer referring to?
    int *mystery2 = &(numbers[0]);

    // TODO: print out the pointer itself, and the value it is pointing to.
    //       hint: use the %p format specifier in printf.


    // TODO: create a new array that contains four int pointers, one for each 
    //       of the 4 integers in 'numbers'. 



    // QUESTION: what is the type of each of these variables?
    //      you may be surprised... try writing some code that uses these two variables.
    float* price1, price2;


    // QUESTION: what happens when I do this? Why do think this happens?
    int *num = &5;


    // QUESTION: what happens here? Will this produce any errors?
    int *myPointer = giveMeAPointer();
    printf("%d\n", *myPointer);

    

    // TODO: figure out what integer is being pointed to by this pointer.
    // note: don't look at the q1_helpers.c file :P Also, 
    //      don't worry about how I managed to return a poitner from a function, 
    //      you'll learn about dynamic memory next week :)
    int ******scaryPointer = createScaryPointer();





    int nums[1000];
    for(int i=0; i<1000; i++){
        nums[i] = i + 1;
    }





    // TODO: create a 1000 pointers, one for each of the 1000 numbers in nums.
    
    int *num_pointers[1000];
    for(int i=0; i<1000; i++){
        num_pointers[i] = &(nums[i]);
    }
    // TODO: calculate the sum of nums USING ONLY the num_pointers array. Forget nums even exists for this exercise.
    
    int sum;
    // your code here

    printf("sum=%d\n", sum);





    // TODO: calculate the sum of nums USING ONLY the num_pointers array WITHOUT using the array
    // access syntax (ie. don't write num_pointers[index] ever to access a value in the array)
    // . Don't use nums here either.
    // hint: using the '+' operator somehow. 

    int sum2;
    // your code here

    printf("sum2=%d\n", sum2);



}
