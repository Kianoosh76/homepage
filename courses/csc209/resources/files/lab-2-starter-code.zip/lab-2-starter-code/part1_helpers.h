
int ******createScaryPointer();