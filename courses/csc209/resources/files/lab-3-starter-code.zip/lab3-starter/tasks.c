#include <stdlib.h>
#include <stdio.h>



// allocates memory on the heap for a new int array of length <size>
// SCROLL TO BOTTOM OF FILE TO IMPLEMENT THIS FUNCTION
int* allocateIntArrayOnHeap(int length);


 // returns the pointer to the location in the array in which the maximum argv value is stored.
// you can assume <length> >= 1
// SCROLL TO BOTTOM OF FILE TO IMPLEMENT THIS FUNCTION
int** findMax(int *arr, int length);

 


int main(int argc, char **argv) {

    /*
    
    - First, check that this program was run with at least one argument (apart from the default one).
    You can assume each is a string representation of an integer. If not, exit with exit status code 1.
    example: "./a.out 2 3 4" is valid, but "./a.out" is not valid (assuming your executable is called a.out)
    hint: you may want to check what exists in argc[0] before you do anything.


    - Complete the function allocateIntArrayOnHeap, and call it in main to create an array
      that can store all of the integers that are present in the inputted argument strings (after they are 
      converted to ints).

    - In main, store values argv[1], argv[2], ..., argv[c - 1] argv in your array. 
    - Complete the function findMax.
    - Call findMax in main, and using it's result, print out the value of the maxium value stored in the array in main.
    - Compile your code again and execute the following:
        valgrind --leak-check=yes -v ./<your executable name> 2 3 4
      does valgrind detect any issues?
      The last line outputed by valgrind should be: "ERROR SUMMARY: 0 errors from 0 contexts"
    - If you do have some issues, try and resolve them.
      hint: the order that you free the memory allocated for the array, and the memory for the pointer to the max DOES make a difference.
    - If valgrind does not find any issues with your code and everything works, try and introduce a memory leak into your code and run valgrind again. 
    */


   // TODO

}


// allocates memory on the heap for a new int array of length <size>
int* allocateIntArrayOnHeap(int length){
    // TODO
}


 // returns the pointer to the location in the array in which the maximum argv value is stored.
// you can assume <length> >= 1
int** findMax(int *arr, int length){
    // TODO
}



