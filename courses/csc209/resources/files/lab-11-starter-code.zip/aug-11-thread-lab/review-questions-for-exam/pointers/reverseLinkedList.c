// Instructions:
// implement reverseList which takes in a pointer to a ListNode struct (the
// head of the linked list), reverses the entire list, and returns a pointer to
// the head of the reversed linked list.

// Restrictions:
//  The reverseList function must have a *space complexity of O(1)*.

typedef struct ListNode {
    int val;
    struct ListNode *next;
} ListNode;

ListNode *reverseList(ListNode *head) {
    // TODO
}
