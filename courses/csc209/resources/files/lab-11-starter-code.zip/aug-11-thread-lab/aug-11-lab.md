<!DOCTYPE html>
<!-- saved from url=(0049)https://www.teach.cs.toronto.edu/~ajr/209/lab/13/ -->
<html data-darkreader-mode="dynamic" data-darkreader-scheme="dark"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><style class="darkreader darkreader--fallback" media="screen"></style><style class="darkreader darkreader--text" media="screen"></style><style class="darkreader darkreader--invert" media="screen">.jfk-bubble.gtx-bubble, .captcheck_answer_label > input + img, span#closed_text > img[src^="https://www.gstatic.com/images/branding/googlelogo"], span[data-href^="https://www.hcaptcha.com/"] > #icon, #bit-notification-bar-iframe, ::-webkit-calendar-picker-indicator {
    filter: invert(100%) hue-rotate(180deg) contrast(90%) !important;
}</style><style class="darkreader darkreader--inline" media="screen">[data-darkreader-inline-bgcolor] {
  background-color: var(--darkreader-inline-bgcolor) !important;
}
[data-darkreader-inline-bgimage] {
  background-image: var(--darkreader-inline-bgimage) !important;
}
[data-darkreader-inline-border] {
  border-color: var(--darkreader-inline-border) !important;
}
[data-darkreader-inline-border-bottom] {
  border-bottom-color: var(--darkreader-inline-border-bottom) !important;
}
[data-darkreader-inline-border-left] {
  border-left-color: var(--darkreader-inline-border-left) !important;
}
[data-darkreader-inline-border-right] {
  border-right-color: var(--darkreader-inline-border-right) !important;
}
[data-darkreader-inline-border-top] {
  border-top-color: var(--darkreader-inline-border-top) !important;
}
[data-darkreader-inline-boxshadow] {
  box-shadow: var(--darkreader-inline-boxshadow) !important;
}
[data-darkreader-inline-color] {
  color: var(--darkreader-inline-color) !important;
}
[data-darkreader-inline-fill] {
  fill: var(--darkreader-inline-fill) !important;
}
[data-darkreader-inline-stroke] {
  stroke: var(--darkreader-inline-stroke) !important;
}
[data-darkreader-inline-outline] {
  outline-color: var(--darkreader-inline-outline) !important;
}
[data-darkreader-inline-stopcolor] {
  stop-color: var(--darkreader-inline-stopcolor) !important;
}</style><style class="darkreader darkreader--variables" media="screen">:root {
   --darkreader-neutral-background: #131516;
   --darkreader-neutral-text: #d8d4cf;
   --darkreader-selection-background: #004daa;
   --darkreader-selection-text: #e8e6e3;
}</style><style class="darkreader darkreader--root-vars" media="screen"></style><style class="darkreader darkreader--user-agent" media="screen">html {
    background-color: #181a1b !important;
}
html {
    color-scheme: dark !important;
}
html, body {
    background-color: #181a1b;
}
html, body {
    border-color: #736b5e;
    color: #e8e6e3;
}
a {
    color: #3391ff;
}
table {
    border-color: #545b5e;
}
::placeholder {
    color: #b2aba1;
}
input:-webkit-autofill,
textarea:-webkit-autofill,
select:-webkit-autofill {
    background-color: #404400 !important;
    color: #e8e6e3 !important;
}
::selection {
    background-color: #004daa !important;
    color: #e8e6e3 !important;
}
::-moz-selection {
    background-color: #004daa !important;
    color: #e8e6e3 !important;
}</style>

<title>CSC 209 lab exercises, week of 9 August 2022</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style type="text/css">
    body {
        color: black;
        background-color: #ffe7e7;
    }
    hr {
        border-style: solid;
    }
    div.toc {
        float: right;
        padding-left: 20px;
        padding-right: 20px;
        padding-top: 20px;
        padding-bottom: 20px;
        background-color: #cc7777;
        color: white;
        link: white;
        visited: white;
        line-height: 150%;
    }
    div.toc a:link {
        color: white;
    }
    div.toc a:visited {
        color: white;
    }
    td {
	padding: 10px;
	text-align: center;
    }

    .hidden { display: none; }
    .unhidden { display: block; }
</style><style class="darkreader darkreader--sync" media="screen"></style>

<script type="text/javascript">
    function show(s) {
        document.getElementById(s).className = 'unhidden';
    }
    function reveal(s) {
        document.getElementById(s+'_a').className = 'hidden';
        document.getElementById(s+'_b').className = 'revealed';
    }
</script>

<meta name="darkreader" content="f715a4f40e5b44009223e3d1bb05740f"><style class="darkreader darkreader--override" media="screen">.vimvixen-hint {
    background-color: #7b5300 !important;
    border-color: #d8b013 !important;
    color: #f3e8c8 !important;
}
::placeholder {
    opacity: 0.5 !important;
}
#edge-translate-panel-body,
.MuiTypography-body1 {
    color: var(--darkreader-neutral-text) !important;
}
gr-main-header {
    background-color: #0f3a48 !important;
}
.tou-z65h9k,
.tou-mignzq,
.tou-1b6i2ox,
.tou-lnqlqk {
    background-color: var(--darkreader-neutral-background) !important;
}
.tou-75mvi {
    background-color: #032029 !important;
}
.tou-ta9e87,
.tou-1w3fhi0,
.tou-1b8t2us,
.tou-py7lfi,
.tou-1lpmd9d,
.tou-1frrtv8,
.tou-17ezmgn {
    background-color: #0a0a0a !important;
}
.tou-uknfeu {
    background-color: #231603 !important;
}
.tou-6i3zyv {
    background-color: #19576c !important;
}</style></head>

<body>



<h1>CSC 209 lab 13, August 11, 2022</h1>


<b>Lab created by Alan J Rosenthal. These problems can also be found at https://www.teach.cs.toronto.edu/~ajr/209/probs/pthreads/ </b>

<h2> Exercise one </h2>

The "Sieve of Eratosthenes" is an ancient method of finding prime numbers
attributed to Eratosthenes, born in 276 BCE.

<p>
Imagine a board of 100 numbers:
</p><p>
</p><table border="3">
<tbody><tr><td align="center">1</td><td align="center">2</td><td align="center">3</td><td align="center">4</td><td align="center">5</td><td align="center">6</td><td align="center">7</td><td align="center">8</td><td align="center">9</td><td>10</td></tr>
<tr><td>11</td><td>12</td><td>13</td><td>14</td><td>15</td><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td></tr>
<tr><td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td><td>29</td><td>30</td></tr>
<tr><td>31</td><td>32</td><td>33</td><td>34</td><td>35</td><td>36</td><td>37</td><td>38</td><td>39</td><td>40</td></tr>
<tr><td>41</td><td>42</td><td>43</td><td>44</td><td>45</td><td>46</td><td>47</td><td>48</td><td>49</td><td>50</td></tr>
<tr><td>51</td><td>52</td><td>53</td><td>54</td><td>55</td><td>56</td><td>57</td><td>58</td><td>59</td><td>60</td></tr>
<tr><td>61</td><td>62</td><td>63</td><td>64</td><td>65</td><td>66</td><td>67</td><td>68</td><td>69</td><td>70</td></tr>
<tr><td>71</td><td>72</td><td>73</td><td>74</td><td>75</td><td>76</td><td>77</td><td>78</td><td>79</td><td>80</td></tr>
<tr><td>81</td><td>82</td><td>83</td><td>84</td><td>85</td><td>86</td><td>87</td><td>88</td><td>89</td><td>90</td></tr>
<tr><td>91</td><td>92</td><td>93</td><td>94</td><td>95</td><td>96</td><td>97</td><td>98</td><td>99</td><td>100</td></tr>
</tbody></table>

<p>
Remove the 1, since that is neither a prime number nor composite.

</p><p>
Start with the 2, and leave that alone, but punch out (remove from the board)
the numbers 4, 6, 8, 10, and so on - all of the multiples of 2.

</p><p>
Next go to the 3.  Leave that alone, but punch out the numbers 6 (already
punched out), 9, 12 (already punched out), and so on - all of the
multiples of 3.

</p><p>
When we get to the 4, we see that it is punched out, so we don't have to do
anything.

</p><p>
Then we punch out all of the multiples of 5, excluding 5 itself; and so on.

</p><p>
When we're done, we have left a list of the prime numbers less than (or equal
to) 100.

</p><p>
</p><hr width="25%" align="left">
<p>
Write a program using threads to do these "punching out"s in parallel.
</p><p>
Create an array of type int from 2 to 100, to be considered as booleans.
(The easiest way to do this is with "int&nbsp;sieve[101];" and ignore sieve[0]
and sieve[1].)
</p><p>
Set all of the values to true (1).
</p><p>
Then create a thread for each of the numbers from 2 to 100 inclusive, which
will do the "punching out" for that number.  These threads must run in
parallel.

</p><p>
After you "pthread_join" (wait for) all the threads, print the numbers
corresponding to all of the 1 values left in the array.

</p><p>
Note that this evades any concurrency issues - if two threads set a
particular int to zero simultaneously, no harm is done.

</p><p>
Unlike the real Sieve of Eratosthenes, you will not be doing the optimization
of, for example, seeing that 4 is already punched out and not bothering to do
the algorithm for 4.  This <i>would</i> raise concurrency
issues.

</p><p>
NOTE: In standard software tools fashion,
your output should be just the prime numbers, no more and no less, with
one number per line (like the output of "seq").



</p><p></p><hr>
<h2> Exercise four </h2>

Please see another good pthreads problem as item #1 in
the <a href="https://www.teach.cs.toronto.edu/~ajr/209/probs/pthreads/">https://www.teach.cs.toronto.edu/~ajr/209/probs/pthreads/</a> .







</body></html>
