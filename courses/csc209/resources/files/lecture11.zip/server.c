#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/select.h>

int main(){
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd == -1){
		perror("socket");
		return 1;
	}

	struct sockaddr_in server = {AF_INET, htons(8000), {inet_addr("127.0.0.1")}};

	if (bind(sockfd, (struct sockaddr *)&server, sizeof(server)) == -1){
		perror("bind");
		return 1;
	}

	if (listen(sockfd, 100) == -1){
		perror("listen");
		return 1;
	}

	struct sockaddr_in client;
	int len = sizeof(client);

	int fd = accept(sockfd, (struct sockaddr *)&client, &len);

	if (fd == -1){
		perror("accept");
		return 1;
	}

	printf("new connection from %s:%d\n", inet_ntoa(client.sin_addr), ntohs(client.sin_port));

	while (true){
		fd_set set;
		FD_ZERO(&set);
		FD_SET(fd, &set);
		FD_SET(STDIN_FILENO, &set);

		if (select(fd + 1, &set, NULL, NULL, NULL) == -1){
			perror("select");
		}

		if (FD_ISSET(fd, &set)){
			char buf[100] = {};
			if (read(fd, buf, 100) == -1){
				close(fd);
				break;
			}
			printf("client says %s\n", buf);
		}

		if (FD_ISSET(STDIN_FILENO, &set)){
			char buf[100];
			scanf("%s", buf);
			if (write(fd, buf, strlen(buf) + 1) == -1){
				close(fd);
				break;	
			}
		}
	}

	close(sockfd);
}
