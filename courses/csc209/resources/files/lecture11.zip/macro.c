#include <stdio.h>

#define MAX 10

const int MAX2 = 10;

int sqr2(int a){
	return a * a;
}

//#define PRINT(X) do { int __y = sqr((X)); printf("%d\n", (__y)); } while(0)

#define PRINT(X) printf("%s: %d\n", #X, X)

#define FUNGEN(name, op, type) type name (type _x) { return _x op _x; }
#define FOR(i, a, b) for (int (i) = (a); (i) < (b); (i)++)
FUNGEN(sqr, *, int)

void print(int x){
	int y = sqr(x);
	printf("%d\n", y);
}

int main(){
	//printf("%d\n", sqr(a++));
	//printf("%d\n", SQR(b++)); // printf("%d\n", int _c = b++; _c * _c);
	FOR(i, 1, 10){
		FOR(j, 0, 10){
			PRINT(i * j);
		}
	}
	int d = sqr(4);
		PRINT(d);
}
