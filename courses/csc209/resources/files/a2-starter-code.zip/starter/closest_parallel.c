#include "closest_parallel.h"

int curr_depth = 0;

double _closest_parallel(struct Point P[], size_t n, int pdmax, int *pcount)
{
    static int num_forks = 0;
    return 0.0;
}

double closest_parallel(struct Point P[], size_t n, int pdmax, int *pcount)
{
    return 0.0;
}
