#include "closest_helpers.h"

int verbose = 0;

int compare_x(const void* a, const void* b) 
{
    return 0;
} 

int compare_y(const void* a, const void* b) 
{ 
    return 0;
} 

double dist(struct Point p1, struct Point p2) 
{
    return 0.0;
} 
