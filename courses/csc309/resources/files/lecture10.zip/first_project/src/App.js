import logo from './logo.svg';
import './App.css';
import Converter from "./components/Converter";
import Calculator from "./components/Calculator";
import Players from "./components/Players";

function App() {
  return (
      <Players />
  );
}

export default App;


var x = "hello";
export { x };