import Button from "../Button";
import "./style.css"
import {useState} from "react";

const Calculator = () => {
    const [expr, setExpr] = useState("");

    const buttons = [
        "7", "8", "9", "/",
        "4", "5", "6", "*",
        "1", "2", "3", "-",
        "0", ".", "=", "+"
    ]

    const update = value => {
        if (value !== "=")
            setExpr(expr + value)
        else
            setExpr(eval(expr))
    }

    return <div className="container">
        <input type="text" value={expr} readOnly style={{fontSize: '2em', gridColumn: '1 / 5'}} />
        {buttons.map(button => (
            <Button
                key={button}
                value={button}
                update={update}
                isOperator={isNaN(button)}
            />
        ))}
    </div>
}

export default Calculator;