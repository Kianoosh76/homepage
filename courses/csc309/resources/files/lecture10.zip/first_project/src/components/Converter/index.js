import React, {useEffect, useState} from 'react';
import Input from "../Input";

const Converter = () => {

    console.log("component is rendered")
    const [celsius, setCelsius] = useState(0);

    var x = 1;

    useEffect(() => {
        console.log("value of celsius changed to " + celsius + x)
    }, [celsius, x])


    const update = isCelsius => value => {
        setCelsius(isCelsius ? value : (value - 32) * 5 / 9)
    }

    return <>
        <Input title="Celsius" value={celsius} update={update(true)}/>
        <span>=</span>
        <Input title="Fahrenheit" value={celsius * 9 / 5 + 32} update={update(false)}/>
    </>

}

// class Converter1 extends React.Component {
//     constructor(props){
//         super(props)
//         this.state = {
//             celsius: 0,
//         }
//     }
//
//     update = isCelsius => value => {
//         this.setState({
//             celsius: isCelsius ? value : (value - 32) * 5 / 9
//         })
//     }
//
//     render(){
//         return <>
//             <Input title="Celsius" value={this.state.celsius} update={this.update(true)}/>
//             <span>=</span>
//             <Input title="Fahrenheit" value={this.state.celsius * 9 / 5 + 32} update={this.update(false)}/>
//         </>
//     }
// }

export default Converter;
