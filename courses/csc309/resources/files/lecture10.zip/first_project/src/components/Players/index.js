import {useEffect, useState} from "react";
import Input from "../Input";
import Button from "../Button";

const Players = () => {
    const [players, setPlayers] = useState([])
    const [query, setQuery] = useState({search: '', page: 1})
    const [totalPages, setTotalPages] = useState(1)

    useEffect(() => {
        fetch(`https://www.balldontlie.io/api/v1/players/?search=${query.search}&page=${query.page}`)
            .then(response => response.json())
            .then(json => {
                setPlayers(json.data)
                setTotalPages(json.meta.total_pages)
            })
    }, [query])

    return (<>
        <Input title="player name"
               value={query.search}
               update={(value) => setQuery({search: value, page: 1})}/>
        <table>
            <thead>
                <tr>
                    <th>first name</th>
                    <th>last name</th>
                    <th>position</th>
                    <th>height</th>
                    <th>team</th>
                </tr>
            </thead>
            <tbody>
            {players.map(player => (
                <tr key={player.id}>
                    <td>{player.first_name}</td>
                    <td>{player.last_name}</td>
                    <td>{player.position}</td>
                    <td>{player.height_feet ? `${player.height_feet}' ${player.height_inches}"` : ''}</td>
                    <td>{player.team.name}</td>
                </tr>
            ))}
            </tbody>
        </table>
        {query.page > 1 ? <Button value="prev" update={() => setQuery({...query, page: query.page - 1})} /> : <></>}
        {query.page < totalPages ? <Button value="next" update={() => setQuery({...query, page: query.page + 1})} /> : <></>}
    </>)
}

export default Players;