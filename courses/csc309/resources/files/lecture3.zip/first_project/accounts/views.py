from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseRedirect
from django.shortcuts import render
from django.template.response import TemplateResponse
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt


def hello(request, name):
    print(request.method, request.GET)
    return HttpResponse(f"Hey {name}, how you doing!!!?")


def signup(request):
    if request.method == "GET":
        return TemplateResponse(request, 'accounts/signup.html')
    else:
        error = ''
        if not request.POST['username']:
            error = "Username is required"
        if request.POST['password'] != request.POST['password2']:
            error = "Passwords do not match"

        if error:
            return TemplateResponse(request, 'accounts/signup.html', context={'error': error})

        return HttpResponseRedirect(reverse('accounts:hello', args=[request.POST['username']]))
