from rest_framework import serializers

from products.models import Store


class StoreSerializer(serializers.ModelSerializer):
    owner = serializers.CharField(source='owner.get_full_name', read_only=True)

    class Meta:
        model = Store
        fields = ['owner', 'name', 'description', 'url', 'email', 'avatar']
