from django.urls import path

from products.views import StoresView, CreateStoreView, StoreView, UpdateStoreView

app_name = 'products'

urlpatterns = [
    path('stores/', StoresView.as_view(), name='stores'),
    path('stores/new/', CreateStoreView.as_view(), name='create-store'),
    path('stores/<int:id>/', StoreView.as_view(), name='store'),
    path('stores/edit/', UpdateStoreView.as_view(), name='update-store'),
]
