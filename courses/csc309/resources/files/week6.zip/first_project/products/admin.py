from django.contrib import admin
from django.contrib.admin import register

# Register your models here.
from products.models import Store, Product


class ProductInline(admin.TabularInline):
    model = Product
    fields = ['name', 'price']
    extra = 2


@register(Store)
class StoreAdmin(admin.ModelAdmin):
    fields = ['name', 'url', 'email', 'avatar']
    readonly_fields = ['avatar']
    inlines = [ProductInline]

