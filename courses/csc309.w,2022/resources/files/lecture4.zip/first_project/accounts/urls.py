from django.urls import path

from accounts.views import hello, signup, login_view

app_name = 'accounts'

urlpatterns = [
    path('hello/<str:name>', hello, name='hello'),
    path('login/', login_view, name='login'),
    path('signup/', signup, name='signup'),
]
