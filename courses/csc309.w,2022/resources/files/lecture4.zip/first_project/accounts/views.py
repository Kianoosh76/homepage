from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseRedirect
from django.shortcuts import render
from django.template.response import TemplateResponse
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt


def hello(request, name):
    print(request.method, request.GET)
    return HttpResponse(f"Hey {request.GET.get('title', '')} {request.user.email} how is it going?")


def login_view(request):
    if request.method == 'GET':
        return TemplateResponse(request, 'accounts/login.html')
    elif request.method == 'POST':
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user:
            login(request, user)
            return HttpResponseRedirect(reverse('accounts:hello', args=[user.username]))
        else:
            error = 'Username or password is incorrect'
            return TemplateResponse(request, 'accounts/login.html', context={'error': error})


def signup(request):
    if request.method == "GET":
        return TemplateResponse(request, 'accounts/signup.html')
    elif request.method == 'POST':
        print(request.POST)

        errors = []
        if not request.POST['username']:
            errors += ["Username is required"]
        if request.POST['password'] != request.POST['password2']:
            errors += ["Passwords do not match"]

        if not errors:
            try:
                User.objects.create_user(username=request.POST['username'], password=request.POST['password'],
                                         email=request.POST['email'])
            except IntegrityError:
                errors += ['Username is already taken']

        if errors:
            return TemplateResponse(request, 'accounts/signup.html', context={'errors': errors})

        return HttpResponseRedirect(reverse('accounts:hello', args=[request.POST['username']]))
