from django.http import HttpResponse


def hello(request, name):
    print(request.method, request.GET)
    return HttpResponse(f"Hey {request.GET.get('title', '')} {request.user.get_full_name()} how is it going?")
