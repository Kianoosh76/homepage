from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseRedirect
from django.shortcuts import render
from django.template.response import TemplateResponse
from django.urls import reverse
from django.views import View
from django.views.decorators.csrf import csrf_exempt


def login_view(request):
    if request.method == 'GET':
        return TemplateResponse(request, 'accounts/login.html')
    else:
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user:
            login(request, user)
            return HttpResponseRedirect(reverse('accounts:hello', args=[user.username]))
        else:
            error = 'Username or password invalid'
            return TemplateResponse(request, 'accounts/login.html', context={'error': error})

