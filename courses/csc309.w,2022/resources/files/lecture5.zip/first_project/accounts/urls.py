from django.urls import path

from accounts.views.hello import hello
from accounts.views.login import login_view
from accounts.views.signup import SignupView

app_name = 'accounts'

urlpatterns = [
    path('hello/<str:name>', hello, name='hello'),
    path('login/', login_view, name='login'),
    path('signup/', SignupView.as_view(), name='signup'),
]
