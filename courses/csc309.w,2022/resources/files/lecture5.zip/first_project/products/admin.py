from django.contrib import admin

from products.models import Store, Product

admin.site.register(Store)
admin.site.register(Product)
