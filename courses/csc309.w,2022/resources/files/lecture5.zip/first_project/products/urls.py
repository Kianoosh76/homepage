from django.urls import path

from products.views import StoresView

app_name = 'products'

urlpatterns = [
    path('stores/', StoresView.as_view(), name='stores'),
]