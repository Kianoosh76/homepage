from django.contrib.auth.models import User
from django.db import models
from django.db.models import SET_NULL


class Store(models.Model):
    owner = models.OneToOneField(to=User, on_delete=SET_NULL, null=True, related_name='store')
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    url = models.URLField(max_length=300)
    email = models.EmailField()
    avatar = models.ImageField(upload_to='store_avatars/', null=True, blank=True)

    def __str__(self):
        return self.name


class Product(models.Model):
    store = models.ForeignKey(to=Store, on_delete=SET_NULL, null=True, related_name='products')
    name = models.CharField(max_length=100)
    price = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.name} of {self.store}'
