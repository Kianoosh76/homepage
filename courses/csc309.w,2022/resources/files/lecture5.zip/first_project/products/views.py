from django.shortcuts import render
from django.views import View
from django.views.generic import TemplateView, ListView

from products.models import Store


class StoresView(ListView):
    template_name = 'products/stores.html'
    model = Store
    context_object_name = 'stores'

