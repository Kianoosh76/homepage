from django import forms

from products.models import Store


class StoreForm(forms.ModelForm):

    class Meta:
        model = Store
        fields = ['name', 'description', 'url', 'email', 'avatar']
