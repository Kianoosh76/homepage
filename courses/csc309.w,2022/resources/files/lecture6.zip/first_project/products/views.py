from django.shortcuts import render
from django.urls import reverse
from django.views.generic import TemplateView, ListView, FormView
from rest_framework.generics import get_object_or_404, RetrieveAPIView, UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from products.forms import StoreForm
from products.models import Store
from products.serializers import StoreSerializer


class StoresView(ListView):
    template_name = 'products/stores.html'
    model = Store
    context_object_name = 'stores'


class CreateStoreView(FormView):
    form_class = StoreForm
    template_name = 'products/create_store.html'

    def get_success_url(self):
        return reverse('products:stores')

    def form_valid(self, form):
        Store.objects.create(**form.cleaned_data, owner=self.request.user)
        return super().form_valid(form)


class StoreView(RetrieveAPIView):
    serializer_class = StoreSerializer

    def get_object(self):
        return get_object_or_404(Store, id=self.kwargs['id'])


class UpdateStoreView(RetrieveAPIView, UpdateAPIView):
    serializer_class = StoreSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user.store
