from django.contrib.auth.models import User
from django.db import models
from django.db.models import SET_NULL


class Store(models.Model):
    owner = models.OneToOneField(to=User, related_name='store', on_delete=SET_NULL, null=True)
    name = models.CharField(max_length=120)
    description = models.TextField(null=True, blank=True)
    url = models.URLField()
    email = models.EmailField()
    avatar = models.ImageField(upload_to='store_avatars/', null=True, blank=True)

    def __str__(self):
        return self.name


class Product(models.Model):
    store = models.ForeignKey(to=Store, on_delete=SET_NULL, null=True, related_name='products')
    name = models.CharField(max_length=200)
    price = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.name} of {self.store}'
