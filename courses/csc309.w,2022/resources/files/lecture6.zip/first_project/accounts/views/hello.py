from django.http import HttpResponse


def hello(request, name):
    print(request.method, request.GET)
    return HttpResponse(f"Hey {request.GET.get('title', '')} {name} how is it going?")
