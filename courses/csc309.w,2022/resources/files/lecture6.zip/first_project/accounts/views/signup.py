from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseRedirect
from django.shortcuts import render
from django.template.response import TemplateResponse
from django.urls import reverse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import FormView

from accounts.forms.signup import SignupForm


class SignupView(FormView):
    template_name = 'accounts/signup.html'
    form_class = SignupForm

    def get_success_url(self):
        return reverse('accounts:hello', args=[self.request.POST['username']])

    def form_valid(self, form):
        form.cleaned_data.pop('password2')
        User.objects.create_user(**form.cleaned_data)
        return super().form_valid(form)
